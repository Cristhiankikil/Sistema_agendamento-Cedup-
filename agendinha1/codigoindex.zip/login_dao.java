package agendinha1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class login_dao {
	usuario user_local = new usuario();
	private String erro;
	
	public String getErro() {
		return erro;
	}

	public void setErro(String erro) {
		this.erro = erro;
	}

	public int Executa(usuario user_recebido) {
        int resposta = 0;
        try {
            resposta = 0;
            this.erro = "";
            String url = "jdbc:postgresql://localhost:5432/agenda";
            String driver = "org.postgresql.Driver";
            String user = "cedup";
            String senha = "cedup";
            
            String sql = "SELECT * FROM usuarios where email like '"+user_recebido.getEmail()+
            		"' and senha like '"+user_recebido.getSenha()+"'";
            //sql = "";
            Class.forName(driver);
            Connection MyConn = DriverManager.getConnection(url, user, senha);
            
            Statement MyStm = MyConn.createStatement();
			ResultSet m = MyStm.executeQuery(sql);
			while(m.next()){
				user_local.setEmail(m.getString("email"));
				user_local.setSenha(m.getString("senha"));
			}
			
			if (user_local.getEmail().equals(user_recebido.getEmail()) && user_local.getSenha().equals(user_recebido.getSenha())) {
				resposta = 1;
			}
			
            MyConn.close();
        } catch (Exception e) {
            this.setErro(""+e);
            System.out.println("" + e);
        }
        return resposta;
    }
	
}
